document.addEventListener("DOMContentLoaded",function(){
    document.querySelector(".containe").style.display="none";
 });